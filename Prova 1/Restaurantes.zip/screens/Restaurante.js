import { StyleSheet, Text, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import api from '../services/api'
import { FlatList } from 'react-native-gesture-handler'
import { Avatar, Card, IconButton } from 'react-native-paper'

export default function Restaurante(props) {
    
    const navigation = props.navigation

    const [restaurantes, setRestaurantes] = useState([])

    useEffect(() => {
      api.get('/restaurantes').then(resultado => {
        setRestaurantes(resultado.data)
      })
    }, [])
  
    return (
        <View style={styles.container}>

        <FlatList
            data={restaurantes}
            renderItem={({ item }) => {
              return (
                <Card style={{margin:10}} mode='outlined' onPress={() => {navigation.navigate('Detalhes', {id: item.id})}}>
                  <Card.Title
                  title={item.nome}
                  subtitle={item.tipo_cozinha}
                  left={() => <Avatar.Image size={48} source={{ uri: item.imagem }} />}
                  right={() => <IconButton icon="chevron-right" />}
                  />
                </Card>
              )
            }}
            
        />

    </View>
  )
}

const styles = StyleSheet.create({
   
})