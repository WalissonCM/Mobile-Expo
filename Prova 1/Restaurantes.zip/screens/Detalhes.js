import { StyleSheet, Text, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import api from '../services/api'
import { Card, Divider } from 'react-native-paper'
import { ScrollView } from 'react-native-gesture-handler'





export default function Detalhes(props) {

    
    const [detalhes, setDetalhes] = useState([])
    const detalhesId = props.route.params.id
    const [pratos, setPratos] = useState([])
    const pratosId = props.route.params.id
    const [bebidas, setBebidas] = useState([])
    const bebidasId = props.route.params.id
    
   

    useEffect(() => {
      api.get('/restaurantes/' + detalhesId).then(resultado => {
        setDetalhes(resultado.data)
      })
    }, [])

    useEffect(() => {
        api.get('/pratos/'+ detalhesId).then(resultado => {
            setPratos(resultado.data)
        })
      }, [])

      useEffect(() => {
        api.get('/bebidas/' + detalhesId).then(resultado => {
            setBebidas(resultado.data)
        })
      }, [])


   

  return (
    <ScrollView>
    <View style={styles.container}>
        <Text style={{alignSelf: 'center', fontSize: 30}}>Restaurante</Text>

       <Card style={styles.card}  mode='outlined'>
         <Card.Title title={detalhes?.nome} style={{paddingStart: 100}}  />
         <Card.Content >
         <Text >{detalhes?.descricao} </Text>
         </Card.Content>
         <Card.Cover source={{ uri:  detalhes?.imagem }} style={{margin:20, width: 300, alignSelf: 'center'}} />       
        
                <Card.Content style={styles.container} >
                    <View style={styles.label}>
                        <Text variant='bodyLarge' style={{ fontWeight: 'bold' }}>Name:</Text>
                        <Text variant='bodyLarge' >{detalhes?.firstName} {detalhes?.nome}</Text>
                    </View>
                    <View style={styles.label}>
                        <Text variant='bodyLarge' style={{ fontWeight: 'bold' }}>Tipo de Cozinha:</Text>
                        <Text variant='bodyLarge' >{detalhes?.tipo_cozinha}</Text>
                    </View>
                    <View style={styles.label}>
                        <Text variant='bodyLarge' style={{ fontWeight: 'bold' }}>Endereço:</Text>
                        <Text variant='bodyLarge' >{detalhes?.endereco}</Text>
                    </View>
                    <View >
                        <Text variant='bodyLarge' style={{ fontWeight: 'bold', justifyContent: 'center', padding: 5 }}>Horario de Funcionamento:</Text>
                        <Text variant='bodyLarge' >{detalhes?.horario_funcionamento}</Text>
                    </View>
                </Card.Content>
         </Card>
           
         <Text style={{alignSelf: 'center', fontSize: 30}}>Cardapio</Text>

         <Card style={styles.card}  mode='outlined'>
         <Card.Content> 
         <Text style={{alignSelf: 'center', fontSize: 20}}>Pratos</Text>
         <View style={styles.label}>
                        <Text variant='bodyLarge' style={{ fontWeight: 'bold' }}>{pratos?.nome}</Text>
                        <Text variant='bodyLarge' >{pratos?.preco}</Text>
                    </View>
                    <View style={styles.label}>
                        <Text variant='bodyLarge' style={{ fontWeight: 'bold' }}>{pratos?.nome}</Text>
                        <Text variant='bodyLarge' >{pratos?.preco}</Text>
                    </View>
                    <View style={styles.label}>
                        <Text variant='bodyLarge' style={{ fontWeight: 'bold' }}>{pratos?.nome}</Text>
                        <Text variant='bodyLarge' >{pratos?.preco}</Text>
                    </View>
            <Divider style={{margin: 10}} />
                    <Text style={{alignSelf: 'center', fontSize: 20, padding: 5}}>Bebidas </Text>
         <View style={styles.label}>
                        <Text variant='bodyLarge' style={{ fontWeight: 'bold' }}>{bebidas?.nome}</Text>
                        <Text variant='bodyLarge' >{bebidas?.preco}</Text>
                    </View>
                    <View style={styles.label}>
                        <Text variant='bodyLarge' style={{ fontWeight: 'bold' }}>{bebidas?.nome}</Text>
                        <Text variant='bodyLarge' >{bebidas?.preco}</Text>
                    </View>
                    <View style={styles.label}>
                        <Text variant='bodyLarge' style={{ fontWeight: 'bold' }}>{bebidas.nome}</Text>
                        <Text variant='bodyLarge' >{bebidas?.preco}</Text>
                    </View>
         </Card.Content>
         </Card>
    </View>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
   container: {
       flex: 1,
       
   },
    card: {
        alignContent: 'center',
        margin: 10
    },
    label: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        margin: 6
        
    }
})